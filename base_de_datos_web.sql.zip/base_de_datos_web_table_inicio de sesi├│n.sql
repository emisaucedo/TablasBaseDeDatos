
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inicio de sesión`
--
-- Creación: 22-10-2019 a las 23:41:33
--

CREATE TABLE `inicio de sesión` (
  `Correo electrónico` varchar(40) NOT NULL,
  `Contraseña` varchar(35) NOT NULL,
  `ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
