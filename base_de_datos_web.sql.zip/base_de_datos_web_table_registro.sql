
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--
-- Creación: 22-10-2019 a las 23:39:03
--

CREATE TABLE `registro` (
  `Correo electrónico` varchar(40) NOT NULL,
  `Nombre completo` varchar(40) NOT NULL,
  `Contraseña` varchar(35) NOT NULL,
  `Sexo` int(11) NOT NULL,
  `Fecha de nacimiento` int(11) NOT NULL,
  `ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
